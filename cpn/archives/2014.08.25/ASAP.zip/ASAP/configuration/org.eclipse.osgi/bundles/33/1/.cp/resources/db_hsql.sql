--
-- ASAP database structure
--

CREATE TABLE BooleanT (
  b_param int default 0 NOT NULL,
  b_testRun int NOT NULL,
  b_val tinyint NOT NULL,
  PRIMARY KEY  (b_param,b_testRun)
);

CREATE INDEX b_param_index ON BooleanT (b_param);
CREATE INDEX b_testRun ON BooleanT (b_testRun);


CREATE TABLE EnumT (
  e_param int default 0 NOT NULL,
  e_testRun int default 0 NOT NULL,
  e_val int default 0 NOT NULL,
  PRIMARY KEY  (e_param,e_testRun)
);

CREATE INDEX e_param_index ON EnumT (e_param);
CREATE INDEX e_testRun_index ON EnumT (e_testRun);
CREATE INDEX e_val_index ON EnumT (e_val);


CREATE TABLE FloatT (
  f_param int default 0 NOT NULL,
  f_testRun int default 0 NOT NULL,
  f_val float default NULL,
  PRIMARY KEY  (f_param,f_testRun)
);

CREATE INDEX f_param_index ON FloatT (f_param);
CREATE INDEX f_testRun_index ON FloatT (f_testRun);
CREATE INDEX f_val_index ON FloatT (f_val);


CREATE TABLE IntegerT (
  i_param int default 0 NOT NULL,
  i_testRun int default 0 NOT NULL,
  i_val int default NULL,
  PRIMARY KEY  (i_param,i_testRun)
);

CREATE INDEX i_param_index ON IntegerT (i_param);
CREATE INDEX i_testRun_index ON IntegerT (i_testRun);
CREATE INDEX i_val_index ON IntegerT (i_val);

CREATE TABLE BlobT (
  b_param int default 0 NOT NULL,
  b_testRun int default 0 NOT NULL,
  b_val longvarbinary default NULL,
  PRIMARY KEY  (b_param,b_testRun)
);

CREATE INDEX bl_param_index ON BlobT (b_param);
CREATE INDEX bl_testRun_index ON BlobT (b_testRun);

CREATE TABLE ParameterTypes (
  pt_name char default '' NOT NULL,
  PRIMARY KEY (pt_name)
);

INSERT INTO ParameterTypes (pt_name) VALUES ('IntegerT');
INSERT INTO ParameterTypes (pt_name) VALUES ('StringT');
INSERT INTO ParameterTypes (pt_name) VALUES ('FloatT');
INSERT INTO ParameterTypes (pt_name) VALUES ('TimeT');
INSERT INTO ParameterTypes (pt_name) VALUES ('EnumT');
INSERT INTO ParameterTypes (pt_name) VALUES ('BooleanT');
INSERT INTO ParameterTypes (pt_name) VALUES ('BlobT');


CREATE TABLE Parameter (
  p_name varchar(255) default '' NOT NULL,
  p_type char default '',
  p_id int IDENTITY NOT NULL,
  p_table varchar(255) default NULL,
  PRIMARY KEY (p_id),
  FOREIGN KEY (p_type) REFERENCES ParameterTypes (pt_name)
);

CREATE UNIQUE INDEX p_name ON Parameter (p_name);


CREATE TABLE StringT (
  s_param int default 0 NOT NULL ,
  s_testRun int default 0 NOT NULL,
  s_val LONGVARCHAR,
  PRIMARY KEY  (s_param,s_testRun)
);

CREATE INDEX s_param_index ON StringT (s_param);
CREATE INDEX s_testRun_index ON StringT (s_testRun);


CREATE TABLE TestRun (
  tr_id int IDENTITY NOT NULL,
  PRIMARY KEY  (tr_id)
);

CREATE TABLE TimeT (
  t_param int default 0 NOT NULL,
  t_testRun int default 0 NOT NULL,
  t_val datetime default NULL,
  PRIMARY KEY  (t_param,t_testRun)
);

CREATE INDEX t_param_index ON TimeT (t_param);
CREATE INDEX t_testRun_index ON TimeT (t_testRun);
CREATE INDEX t_val_index ON TimeT (t_val);
