--
-- ASAP database structure
--

CREATE TABLE BooleanT (
  b_param int(11) NOT NULL default '0',
  b_testRun int(11) NOT NULL default '0',
  b_val tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (b_param,b_testRun),
  KEY b_param_index (b_param),
  KEY b_testRun (b_testRun)
);

CREATE TABLE EnumT (
  e_param int(11) NOT NULL default '0',
  e_testRun int(11) NOT NULL default '0',
  e_val int(11) NOT NULL default '0',
  PRIMARY KEY  (e_param,e_testRun),
  KEY e_param_index USING BTREE (e_param),
  KEY e_testRun_index USING BTREE (e_testRun),
  KEY e_val_index USING BTREE (e_val)
);

CREATE TABLE FloatT (
  f_param int(11) NOT NULL default '0',
  f_testRun int(11) NOT NULL default '0',
  f_val float default NULL,
  PRIMARY KEY  (f_param,f_testRun),
  KEY f_param_index USING BTREE (f_param),
  KEY f_testRun_index USING BTREE (f_testRun),
  KEY f_val_index USING BTREE (f_val)
);

CREATE TABLE IntegerT (
  i_param int(11) NOT NULL default '0',
  i_testRun int(11) NOT NULL default '0',
  i_val int(11) default NULL,
  PRIMARY KEY  (i_param,i_testRun),
  KEY i_param_index USING BTREE (i_param),
  KEY i_testRun_index USING BTREE (i_testRun),
  KEY i_val_index USING BTREE (i_val)
);

CREATE TABLE BlobT (
  b_param int default 0 NOT NULL,
  b_testRun int default 0 NOT NULL,
  b_val longblob default NULL,
  PRIMARY KEY  (b_param,b_testRun),
  KEY bl_param_index USING BTREE (b_param),
  KEY bl_testRun_index USING BTREE (b_testRun)
);

CREATE TABLE Parameter (
  p_name varchar(255) NOT NULL default '',
  p_type enum('IntegerT','StringT','FloatT','TimeT','EnumT','UserT','BooleanT') NOT NULL,
  p_id int(11) NOT NULL auto_increment,
  p_table varchar(255) default NULL,
  PRIMARY KEY  (p_id),
  UNIQUE KEY p_name (p_name)
);

CREATE TABLE StringT (
  s_param int(11) NOT NULL default '0',
  s_testRun int(11) NOT NULL default '0',
  s_val text,
  PRIMARY KEY  (s_param,s_testRun),
  KEY s_param_index USING BTREE (s_param),
  KEY s_testRun_index USING BTREE (s_testRun)
);

CREATE TABLE TestRun (
  tr_id int(11) NOT NULL auto_increment,
  PRIMARY KEY  (tr_id)
);

CREATE TABLE TimeT (
  t_param int(11) NOT NULL default '0',
  t_testRun int(11) NOT NULL default '0',
  t_val datetime default NULL,
  PRIMARY KEY  (t_param,t_testRun),
  KEY t_param_index USING BTREE (t_param),
  KEY t_testRun_index USING BTREE (t_testRun),
  KEY t_val_index USING BTREE (t_val)
);
