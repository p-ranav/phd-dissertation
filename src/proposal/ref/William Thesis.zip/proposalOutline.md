#PROPOSAL OUTLINE:
------------------

----------------------------------------------------------------------------
## Introduction:
----------------

### Motivations:
----------------
* CPS systems are becoming increasingly more common; many more types of devices are being given processors and network connectivity
* This push towards IoT creates systems and infrastructure which are heavily dependent on the network resources
* These systems are designed to be deployed once and provide the infrastructure for remotely deploying and managing applications 
* Application verification is required to ensure the stability of the system with respect to the resources provided by the system and required by the applications
* Networking resources are becoming increasingly more relevant to the stability of the system and its applications
* Analyzing these networks and their applications proves difficult, so many systems are over-provisioned / under-utilized; means they cost more to make and can generate less revenue (fewer deployed applications)
* By modeling the applications as well as the systems, we can more precisely determine the resource requirements 
* Component-based software allows for better application modeling and development
* By integrating the network resource requirements into the component models, we can precisely describe th resource requirements of the component-based applications
* Composing the application profiles and the system profiles together allows us to analyse the performance of the system running the applications given the system's provided network capabilities and the applications' required network resources
* Furthermore, component-based software allows us to integrate monitoring and management infrastructure into the applications which can ensure system stability

### Challenges:
---------------
* System time-varying network resource model is very precise, can be difficult to derive; many systems are not as deterministic or periodic as this type of modeling requires
* The application and system network resource profiles require precise specification, which can be difficult to provide
* application network utilization measurements can be imprecise and difficult to derive without a running system
* many types of applications cannot be easily modeled with this type of precise, periodic, deterministic paradigm (esp. data-dependent application network traffic)
* run-time systems require time synchronization
* system infrastructural network traffic is not modeled; simply removed from the system capabilities; not all types of infrastructural traffic is constant or predictable enough for this to be accurate
* most real systems have some form of routing, either static or dynamic; dynamic routing is difficult to analyze for precise performance prediction
* Systems are becoming more adaptive in nature and reacting to events at run-time (essentially data-dependent traffic); this adaptability is hard to provide performance metrics for

### Organization:
-----------------


----------------------------------------------------------------------------
## Related Work:
----------------

### Modeling Network Characteristics:
-------------------------------------

### Network Performance Prediction:
-----------------------------------

### Run-time Network Resource Management:
-----------------------------------------



----------------------------------------------------------------------------
## Design-time Network Performance Analysis:
--------------------------------------------



----------------------------------------------------------------------------
## Design-time Analysis of Statically Routed Networks:
------------------------------------------------------



----------------------------------------------------------------------------
## Run-time Network Performance Monitoring:
-------------------------------------------



----------------------------------------------------------------------------
## Run-time Network Traffic Anomaly Detection and Classification:
-----------------------------------------------------------------

